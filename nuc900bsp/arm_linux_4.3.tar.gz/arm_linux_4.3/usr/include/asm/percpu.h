#ifndef __ARM_PERCPU
#define __ARM_PERCPU

#include <asm-generic/percpu.h>

#endif
