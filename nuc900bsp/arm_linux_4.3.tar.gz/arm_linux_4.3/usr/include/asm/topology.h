#ifndef _ASM_ARM_TOPOLOGY_H
#define _ASM_ARM_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_ARM_TOPOLOGY_H */
